﻿
namespace Microsoft.Azure.Management.ApiManagement.ArmTemplates.Common
{
    public class ProductAPITemplateResource : TemplateResource
    {
    }
}