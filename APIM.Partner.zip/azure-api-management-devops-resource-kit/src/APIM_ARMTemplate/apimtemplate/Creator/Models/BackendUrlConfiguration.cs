using System.Collections.Generic;


namespace Microsoft.Azure.Management.ApiManagement.ArmTemplates.Create
{
    public class BackendUrlsConfig
    {
        public string apiName { get; set; }
        public string apiUrl { get; set; }
    }
}