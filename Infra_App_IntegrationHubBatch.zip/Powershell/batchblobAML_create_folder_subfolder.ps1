param(
    [string[]]$storageaccaml,
    [string[]]$rgName
)

az extension add -n storage-preview

$sacckey = az storage account keys list -g $rgName -n  $storageaccaml  --query [0].value

#@{} - creates a hash
#@() - adds an array

$myMap = @{ 
"fcrminputfiles" = @("ADS Salesforce/Archive"
"Alloy KYC/Archive"
"Bread Classic and 2.0/Archive"
"Bread Merchant Salesforce/Archive"
"Corserv KYC/Archive"
"Employee/Archive"
"Jack Henry/Archive"
"Subpoena/Archive"
"TSYS Commercial Cards/Archive"
"UAR/Archive")
"fcrmoutputfiles" = @("ADS Salesforce/Archive"
"Alloy KYC/Archive"
"Bread Classic and 2.0/Archive"
"Bread Merchant Salesforce/Archive"
"Corserv KYC/Archive"
"Employee/Archive"
"Jack Henry/Archive"
"Subpoena/Archive"
"TSYS Commercial Cards/Archive"
"UAR/Archive")
} 

foreach($container in $myMap.keys)
{
foreach($blobcontainer in $myMap["$container"])
{
$dirpresent = az storage fs directory exists -n $blobcontainer -f $container --account-name $storageaccaml  --account-key $sacckey --query "exists"

if($dirpresent -eq $true)
{
echo "Directory already exists !!"
}
else
{
echo "Creating a directory!!"

az storage fs directory create -n $blobcontainer -f $container --account-name $storageaccaml --account-key $sacckey

echo "Directory created!!"
}
}
}

