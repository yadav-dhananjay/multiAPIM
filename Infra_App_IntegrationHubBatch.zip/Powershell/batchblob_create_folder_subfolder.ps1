param(
    [string[]]$storageacc,
    [string[]]$rgName
)

az extension add -n storage-preview

$sacckey = az storage account keys list -g $rgName -n  $storageacc  --query [0].value

#@{} - creates a hash
#@() - adds an array

$myMap = @{ 
# "protegrity" = @("Protect_Input"
# "Protect_Output" 
# "Protect_Error"
# "UnProtect_Input"
# "UnProtect_Output"
# "UnProtect_Error")
# "protegrity-unprotect" = @("File_Repository"
# "UnProtect_Input"
# "UnProtect_Output"
# "UnProtect_Error")
"disputes" = @("Input" 
"Output"
"Archival"
"Error")
"authorizations" = @("NewBenefits/Input"
"NewBenefits/Output"
"NewBenefits/Archival"
"NewBenefits/Error"
"ReunionGroup/Input"
"ReunionGroup/Output"
"ReunionGroup/Archival"
"ReunionGroup/Error"
"Clarus/Input"
"Clarus/Output"
"Clarus/Archival"
"Clarus/Error")
"customerid" = @("input"
"output"
"archive")
} 

foreach($container in $myMap.keys)
{
foreach($blobcontainer in $myMap["$container"])
{
$dirpresent = az storage fs directory exists -n $blobcontainer -f $container --account-name $storageacc  --account-key $sacckey --query "exists"

if($dirpresent -eq $true)
{
echo "Directory already exists !!"
}
else
{
echo "Creating a directory!!"

az storage fs directory create -n $blobcontainer -f $container --account-name $storageacc --account-key $sacckey

echo "Directory created!!"
}
}
}

