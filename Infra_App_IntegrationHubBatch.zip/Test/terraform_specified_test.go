package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestVirtualMachine(t *testing.T) {
	//t.Parallel()
	terraformOptions := &terraform.Options{
	  TerraformDir : "./Fixtures/virtualmachine",
  
	  Vars : map[string]interface{} {
		"vm_nic_name"				 	: "nic-ACS29W280-test",
		"ipcofig_name"                  : "internal",
		"vm_nsg"						: "nsg-ads-eus2-entbusops-dev-extweb-001",
		"private_ip_allocation"         : "Static",
		"private_ip_address"			: "10.40.250.8",
		"vm_name"						: "ACS29W280-test",
		"region"						: "eastus2",
		"resource_group_name"			: "rg-ads-eus2-entbusops-dev-ihub-batch-001",
		"vm_admin_username"				: "ACS29W280ADMIN",
		"keyvault_name"					: "kvadseus2devihubbatch01",
		"keyvault_secret_name"			: "ACS29W280ADMIN-PW-Key",
		"nsg_rgname"                    : "rg-ads-eus2-entbusops-dev-sec-001",
		"vmsize"                        : "Standard_F2s_v2",
		"publisher"                     : "MicrosoftWindowsServer",
		"offer"                         : "WindowsServer",
		"sku"                           : "2019-Datacenter",
		"os_version"                    : "latest",
		"caching"                       : "ReadWrite",
		"storage_account_type"          : "Standard_LRS",
		"encryption_at_host_enabled"    : "true",
		"identity_type"                 : "SystemAssigned",
		"data_vmsubnet_name"			: "sn-ads-eus2-entbusops-dev-extweb-001",
		"zone"                          : "1",
		"vnet_resourcegroup_name"       : "rg-ads-eus2-entbusops-dev-nw-001",
		"data_vmvnet_name"              : "vnet-ads-eus2-entbusops-ext-dev-001",
		"enablevm"                      : true,
		"enablenic"                     : true,
		"enable_network_interface_nsg"  : true,
	  },
	}
	  // At the end of the test, run `terraform destroy` to clean up any resources that were created
	  defer terraform.Destroy(t, terraformOptions)
  
	  // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	  terraform.InitAndApply(t, terraformOptions)
  
	  //Module Name from main.tf
	  output := terraform.Output(t, terraformOptions, "vmname")
	  assert.Equal(t, "ACS29W280-test",output)
  }

func TestLoadBalancer(t *testing.T) {
	//t.Parallel()
	terraformOptions := &terraform.Options{
	  TerraformDir : "./Fixtures/load_balancer",
  
	  Vars : map[string]interface{} {
		"vm_nic_name"				 	: "nic-ACS29W281-test",
		"ip_config_name"                : "internal",
		"vm_nsg"						: "nsg-ads-eus2-entbusops-dev-app-globalscape-001",
		"private_ip_allocation"         : "Dynamic",
		"vm_name"						: "ACS29W281-test",
		"vm_admin_username"				: "ACS29W281ADMIN",
		"vm_admin_password"			  	: "ALPOn+KghfLasd$@t0nAw134",
		"nsg_rgname"                    : "rg-ads-eus2-entbusops-dev-sec-001",
		"vm_size"                       : "Standard_F2s_v2",
		"publisher"                     : "MicrosoftWindowsServer",
		"offer"                         : "WindowsServer",
		"sku"                           : "2019-Datacenter",
		"os_version"                    : "latest",
		"caching"                       : "ReadWrite",
		"storage_account_type"          : "Standard_LRS",
		"encryption_at_host_enabled"    : "true",
		"identity_type"                 : "SystemAssigned",	
		"zones"                         : "1",
		"lbname"				 	    : "ilb-ads-eus2-entbusops-dev-globalscape-dmz-001-test",
		"region"						: "eastus2",
		"resource_group_name"			: "rg-ads-eus2-entbusops-dev-ihub-batch-001",
		"lb_sku"				        : "Standard",
		"frontendname"                  : "fe-globalscape-dev-dmz-001",
		"private_ip_address_version"    : "IPv4",
		"ipaddress"                     : "10.40.250.125",
		"ip_address_assignment"         : "Static",
		"data_lbvnet_name"              : "vnet-ads-eus2-entbusops-ext-dev-001",
		"data_lbsubnet_name"			: "sn-ads-eus2-entbusops-dev-extweb-001",
		"vnet_resourcegroup_name"       : "rg-ads-eus2-entbusops-dev-nw-001",
		"backendpoolname"               : "be-globalscape-dev-dmz-001",
		"healthprobename"               : "hp-tcp-21",
		"lbrulename"					: "lbr-entbusops-globalscape-dmz-dev-001",
		"lbport"						: "21",
		"fename"						: "fe-globalscape-dev-dmz-001",
		"port"						    : "21",
		"lbprotocol"                    : "TCP",
		"interval"                      : "5",
		"unhealthy_threshold"           : "3",
		"timeoutinmin"                  : "5",
		"subscription_id"				: "1fd4eaa2-e0f5-4e47-a395-12bad3a0cd73",
	},
   }
	  // At the end of the test, run `terraform destroy` to clean up any resources that were created
	  defer terraform.Destroy(t, terraformOptions)
  
	  // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	  terraform.InitAndApply(t, terraformOptions)
  
	  //Module Name from main.tf
	  output := terraform.Output(t, terraformOptions, "load_balancer")
	  assert.Equal(t, "ilb-ads-eus2-entbusops-dev-globalscape-dmz-001-test",output)
  }

func TestEventgriddomain(t *testing.T) {
	//t.Parallel()
	terraformOptions := &terraform.Options{
		TerraformDir: "./Fixtures/Eventgriddomin",

		Vars: map[string]interface{}{
			"region":                          "eastus2",
			"rgName":                          "rg-ads-eus2-entbusops-dev-ihub-batch-001",
			"gridname":                        "eg-ads-eus2-entbusops-dev-ihub-batch-001-test",
			"schema":                          "EventGridSchema",
			"public_network_access_enabled":   "false",
			"enableeventgrid":                 "true",
			"enable_eventgriddomain_pep":      "true",
			"eventgrid_domain_end_point_name": "pep-eg-ads-eus2-entbusops-dev-ihub-batch-001-test",
			"pep_subnet_id":                   "/subscriptions/1fd4eaa2-e0f5-4e47-a395-12bad3a0cd73/resourceGroups/rg-ads-eus2-entbusops-dev-nw-001/providers/Microsoft.Network/virtualNetworks/vnet-ads-eus2-entbusops-int-dev-001/subnets/sn-ads-eus2-entbusops-dev-pep-001",
		},
	}
	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	//Module Name from main.tf
	output := terraform.Output(t, terraformOptions, "eventgriddomain")
	assert.Equal(t, "eg-ads-eus2-entbusops-dev-ihub-batch-001-test", output)
	
}

func TestEventgridtopic(t *testing.T) {
	//t.Parallel()
	terraformOptions := &terraform.Options{
		TerraformDir: "./Fixtures/Eventgridtopic",

		Vars: map[string]interface{}{
			"region":                         "eastus2",
			"rgName":                         "rg-ads-eus2-entbusops-dev-ihub-batch-001",
			"topicname":                      "egt-ads-eus2-entbusops-dev-ihub-batch-blob-001-t",
			"schema":                         "EventGridSchema",
			"enableeventgridtopic":           "true",
			"enable_eventgridtopic_app_pep":  "true",
			"eventgrid_topic_end_point_name": "pep-egt-ads-eus2-entbusops-dev-ihub-batch-001-test",
			"pep_subnet_id":                  "/subscriptions/1fd4eaa2-e0f5-4e47-a395-12bad3a0cd73/resourceGroups/rg-ads-eus2-entbusops-dev-nw-001/providers/Microsoft.Network/virtualNetworks/vnet-ads-eus2-entbusops-int-dev-001/subnets/sn-ads-eus2-entbusops-dev-pep-001",
		},
	}
	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	//Module Name from main.tf
	output := terraform.Output(t, terraformOptions, "eventgridtopic")
	assert.Equal(t, "egt-ads-eus2-entbusops-dev-ihub-batch-blob-001-t", output)

}

//Mssql starting


func TestMsSql(t *testing.T) {
	// t.Parallel()
  
	  terraformOptions := &terraform.Options{
  
		
		TerraformDir : "./Fixtures/mssql-db",
	  
	   Vars: map[string]interface{}{
	 
		"rgName"                        : "rg-ads-eus2-entbusops-dev-ihub-batch-001",
		"key_vault_name"                : "kvadseus2devihubbatch01",
		"prim_keyvault_secret_name"     : "ACS26X005-adssqladmin",
		"sec_keyvault_secret_name"      : "ACS26X005-adssqladmin",
		"create_primary_server"         : true,
		"primary_sqlserver_name"        : "acs26x005t",
		"primary_sql_location"          : "eastus2",
		"sql_server_version"            : "12.0",
		"primary_administrator_login"   : "adssqladmin",
		"create_secondary_server"       : false,
		"secondary_sqlserver_name"      : "acs26x005t",
		"secondary_sql_location"        : "eastus2",
		"secondary_administrator_login" : "adssqladmin",
		"create_primary_db"             : true,
    	"primary_sqldb_name"            : "sdb-ads-eus2-entbusops-dev-ihub-batch-eft-001-t",
		"sql_collation"                 :  "SQL_Latin1_General_CP1_CI_AS",
		"storageAccountType"            : "GRS",
		"create_secondary_db"           : false,
    	"secondary_sqldb_name"          : "sdb-ads-eus2-entbusops-dev-ihub-batch-adf-001-t",
		"create_mode"                   : "Secondary",
		"create_failover"               : false,
    	"failover_name"                 : "fg-ads-eus2-entbusops-dev-ihub-batch-adf-001-t",
		"mode"                          :  "Manual",
		"create_sql_pep"                : true,
		"sql_pep_name"                  : "pep-sdb-ads-eus2-entbusops-dev-ihub-batch-adf-001-t",
		"pep_sql_location"              : "eastus2",
		"sql_subresource_names"         : "sqlServer",
		"create_sql_pep_eus2"           : false,
		"sqlserver_id"                  : "/subscriptions/1fd4eaa2-e0f5-4e47-a395-12bad3a0cf54d/resourceGroups/rg-ads-eus2-entbusops-dev-ihub-batch-001/providers/Microsoft.Sql/servers/acs26x005t}",
		"sql_pep_name_eus2"             : "pep-sdb-ads-eus2-entbusops-dev-ihub-batch-adf-001-t",
		//retention policy
		"retention_days"                : "35",
		"weekly_retention"              : "P8W",
		"monthly_retention"             : "P24M",
		"yearly_retention"              : "P10Y",
		"week_of_year"                  : "1",
		"ad_login_name"                 : "RET CAD4 SQL Administrators",
		"ad_login_object_id"            : "bec87402-9ea6-4fb6-9028-4ffd0056d26b",
		"public_net_access_enabled"     : false,
		"data_pep_subnet_name"          : "sn-ads-eus2-entbusops-dev-pep-001",
		"data_vnet_name_pep"            : "vnet-ads-eus2-entbusops-int-dev-001",
		"vnet_resourcegroup_name"       : "rg-ads-eus2-entbusops-dev-nw-001",
		"sqldb_key_vault_name"          : "kvadseus2devihubbatch01",
		
    },
  }
  
	  // At the end of the test, run `terraform destroy` to clean up any resources that were created
	  defer terraform.Destroy(t, terraformOptions)
  
	  // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	  terraform.InitAndApply(t, terraformOptions)
  
	 output1 := terraform.Output(t, terraformOptions, "primary_sqldb_name")
     assert.Equal(t, "sdb-ads-eus2-entbusops-dev-ihub-batch-eft-001-t",output1)
    
     output2 := terraform.Output(t, terraformOptions, "primary_sqlserver_name")
	 assert.Equal(t, "acs26x005t",output2)

  
}

  //Mssql end
  
func TestFunctionAppStorageAcc(t *testing.T) {
	// t.Parallel()
  
	  terraformOptions := &terraform.Options{
		
		TerraformDir : "./Fixtures/FunctionAppStorageAcc",
	  
	   Vars: map[string]interface{}{
		"functionName"                 : "fnc-ads-eus2-entbusops-batch-auth-dev-001t",
		"region"                       : "eastus2",
		"rgName"                       : "rg-ads-eus2-entbusops-dev-ihub-batch-001",
		"linuxfxversion"               : "Java|11",
		"IdentityType"                 : "SystemAssigned",
		"ftpsstate"                    : "AllAllowed",
		"http2_enabled"                : true,
		"OSVersion"                    : "3",
		"IsHttpsOnly"                  : true,
		"osType"                       : "linux",
		"auth_settings"                : true,
		"functionWorkerRuntime"        : "java",
		"EnableAppServiceStorage"      : true,
		"funct_end_point_name"         : "pep-fnc-ads-eus2-entbusops-batch-auth-dev-001t",
		"website_contentovervnet"      : "1",
		"saName"                       : "saseus2devbatchblob01t",
		"saTier"                       : "Standard",
		"saRepType"                    : "LRS",
		"NetworkRuleDefaultAction"     : "Deny",
		"storage_end_point_name"       : "pep-sas-ads-eus2-entbusops-dev-ihub-batch-001t",
		"storage_end_point_name_file"  : "pep-sas-azcp-file-ads-eus2-entbusops-dev-ihub-batch-001t",
		"kvname"                       : "kvadseus2devihubbatch01",
		"kvrgname"                     : "rg-ads-eus2-entbusops-dev-ihub-batch-001",
		"appsvcplname"  			   : "appsvcpl-ads-eus2-entbusops-batch-auth-dev-001",
		"func_subnet_name"             : "sn-ads-eus2-entbusops-dev-fnc-001",
		"vnet_name" 				   : "vnet-ads-eus2-entbusops-int-dev-001",
		"pep_subnet_name"              : "sn-ads-eus2-entbusops-dev-pep-001",
		"appinsight_name"              : "apin-ads-eus2-entbusops-dev-ihub-batch-001",
		"subnet_rgname"                : "rg-ads-eus2-entbusops-dev-nw-001",
		"enable_private_dns_zone_group": false,
		"enable_storage_share"		   : false,
		"enable_network_rule"          : false,
		"vnet_subnet_id"               : "1fd4eaa21",
		"enable_vnet_integration"      : false,
	  },
	  // At the end of the test, run `terraform destroy` to clean up any resources that were created
	  defer terraform.Destroy(t, terraformOptions)
  
	  // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	  terraform.InitAndApply(t, terraformOptions)

	  output1 := terraform.Output(t, terraformOptions, "staccname")
	  assert.Equal(t, "saseus2devbatchblob01t",output1)
	  output2 := terraform.Output(t, terraformOptions, "functionAppName")
	  assert.Equal(t, "fnc-ads-eus2-entbusops-batch-auth-dev-001t",output2)
  }

func TestVm_backup_policy(t *testing.T) {
	//t.Parallel()
	terraformOptions := &terraform.Options{
		TerraformDir: "./Fixtures/vm_backup_policy",

		Vars: map[string]interface{}{
			"create_services_vault"						     	: true,
			"recovery_services_vault"							: "rsv-ads-eus2-entbusops-dev-ihub-batch-001t",
			"backup_policy_name"							    : "bup-ads-eus2-entbusops-dev-ihub-batch-001t",
			"vault_sku"						                    : "Standard",
			"soft_delete_enabled"					            : false,
			"timezone"						                    : "Eastern Standard Time",
			"instant_restore_retention_days"				    : 2,
			"frequency"                                        : "Daily",
			"time"                                              : "22:30",
			"count_rdp"											: 30,
			"count_rwp"											: 8,
			"weekdays_rwp"										: "Friday",
			"count_rmp"											: 12,
			"weekdays_rmp"										: "Friday",
			"weeks_rmp"											: "First",
			"count_ryp"                      					: 7,
			"weekdays_ryp"										: "Friday",
			"weeks_ryp"											: "First",
			"months_ryp"										: "January",
			"vm_name" 				                            : "TestVM",
			"enable_protected_vm" 					         	: true,
			"enable_rsv_pep" 					              	: true,
			"region" 											: "eastus2",
			"rgName"											: "rg-ads-eus2-entbusops-dev-ihub-batch-001",
			"rsv_pep" 											: "pep-rsv-ads-eus2-entbusops-dev-ihub-batch-001t",
			"rsv_subresource_names"								: "AzureBackup",
			"data_pep_subnet_name"								: "sn-ads-eus2-entbusops-dev-pep-001",
			"data_vnet_name_pep"								: "vnet-ads-eus2-entbusops-int-dev-001",
			"vnet_resourcegroup_name"							: "rg-ads-eus2-entbusops-dev-nw-001",
			"vm_size"											: "Standard_F2s_v2",
			"zones"												: 1,
			"vm_admin_username"									: "Testvmuser",
			"vm_admin_password"									: "Testvmuser@9",
			"publisher"											: "MicrosoftWindowsServer",
			"offer"												: "WindowsServer",
			"sku"												: "2019-Datacenter",
			"os_version"										: "latest",
			"caching"											: "ReadWrite",
			"storage_account_type"								: "Premium_LRS",
			"encryption_at_host_enabled"						: true,
			"identity_type"										: "SystemAssigned",
			"data_vnet_name"									: "vnet-ads-eus2-entbusops-ext-dev-001",
			"vm_nsg"											: "nsg-ads-eus2-entbusops-dev-app-globalscape-001",
			"nsg_rgname"										: "rg-ads-eus2-entbusops-dev-sec-001",
			"vm_nic_name"										: "nic-TestVM-test",
			"ip_config_name"									: "internal",
			"private_ip_allocation"								: "Dynamic",
			"data_subnet_name"									: "sn-ads-eus2-entbusops-dev-extweb-001",
			


	
		},
   }
		      // At the end of the test, run `terraform destroy` to clean up any resources that were created
	  defer terraform.Destroy(t, terraformOptions)
  
	  // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	  terraform.InitAndApply(t, terraformOptions)
  
	  //Module Name from main.tf
	  output := terraform.Output(t, terraformOptions, "recovery_services_vault_name")
	  assert.Equal(t, "rsv-ads-eus2-entbusops-dev-ihub-batch-001t",output)
}