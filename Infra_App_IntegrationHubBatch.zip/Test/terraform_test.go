package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

 func TestAppInsight(t *testing.T) {
	// t.Parallel()
 terraformOptions := &terraform.Options{
   TerraformDir : "./Fixtures/AppInsight",
 
   Vars: map[string]interface{}{
  "region"            : "eastus2",
  "rgName"            : "rg-ads-eus2-entbusops-dev-ihub-batch-001",
  "appinsight_name"   : "apin-ads-eus2-entbusops-dev-ihub-batch-001-test",
  "application_type"  : "web", 
},
}
   // At the end of the test, run `terraform destroy` to clean up any resources that were created
   defer terraform.Destroy(t, terraformOptions)

   // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
   terraform.InitAndApply(t, terraformOptions)

  output := terraform.Output(t, terraformOptions, "appinsights_name")
	  assert.Equal(t, "apin-ads-eus2-entbusops-dev-ihub-batch-001-test",output)
}


//func TestAvailabilitySet(t *testing.T) {
func TestAvailabilitySet(t *testing.T) {
	//t.Parallel()
	terraformOptions := &terraform.Options{
		TerraformDir: "./Fixtures/availabilityset",

		Vars: map[string]interface{}{
			"region":              "eastus2",
			"aset_name":           "as-ads-eus2-entbusops-dev-globalscape-eft-001-test",
			"resource_group_name": "rg-ads-eus2-entbusops-dev-ihub-batch-001",
			"updatedomain":        "1",
			"faultdomain":         "1",
		},
	}
	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	//Module Name from main.tf
	output := terraform.Output(t, terraformOptions, "availability-set")
	assert.Equal(t, "as-ads-eus2-entbusops-dev-globalscape-eft-001-test", output)
}

func TestTrafficmanager(t *testing.T) {
	//t.Parallel()
	terraformOptions := &terraform.Options{
		TerraformDir: "./Fixtures/Trafficmanager",

		Vars: map[string]interface{}{
			//"region":                       "eastus2",
			"tfname":                       "trmp-ads-eus2-entbusops-dev-ihub-batch-001-test",
			"rgName":                       "rg-ads-eus2-entbusops-dev-ihub-batch-001",
			"routing":                      "Priority",
			"protocol":                     "HTTPS",
			"port":                         "443",
			"path":                         "/",
			"probinginterval":              "30",
			"tolerated_number_of_failures": "5",
			"timeout_in_seconds":           "10",
			"endpointname_sec":             "Secondary",
			"endpointname":					"Primary",	
			"type":                         "externalEndpoints",
			"target":                       "estazd.alliancedata.com",
			"priority":                     "1",
			"target_sec" : 					"estazd.alliancedata.com" ,
			"type_sec":						"externalEndpoints",
			"priority_sec":					"1",
			"enabletm_endpoint_sec":			false,
			"enabletrafficmanager": 			true,
			"enabletrafficmanager_endpoint":   	true,

		},
	}
	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	//Module Name from main.tf
	output := terraform.Output(t, terraformOptions, "trafficmanager")
	assert.Equal(t, "trmp-ads-eus2-entbusops-dev-ihub-batch-001-test", output)
}

/*
func TestPrivateEndPoint(t *testing.T) {
	// t.Parallel()
	terraformOptions := &terraform.Options{
		TerraformDir: "./Fixtures/PrivateEndPoint",
		Vars: map[string]interface{}{
			"privateendpointname":            "pep-sas-ads-eus2-entbusops-dev-ihub-batch-001-test",
			"region":                         "East US 2",
			"rgName":                         "rg-ads-eus2-entbusops-dev-ihub-batch-001",
			"PrivateEndPointSubResourceName": "blob",
		},
	}
	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)
	output := terraform.Output(t, terraformOptions, "private_endpoint")
	assert.Equal(t, "pep-sas-ads-eus2-entbusops-dev-ihub-batch-001-test", output)
}*/

func TestStorageAccount(t *testing.T) {
	// t.Parallel()

	terraformOptions := &terraform.Options{

		TerraformDir: "./Fixtures/storageaccount",

		Vars: map[string]interface{}{
			"saName":                   "saseus2eboihubbatch01t",
			"rgName":                   "rg-ads-eus2-entbusops-dev-ihub-batch-001",
			"region":                   "eastus2",
			"saTier":                   "Standard",
			"saRepType":                "LRS",
			"NetworkRuleDefaultAction": "Deny",
			"min_tls_version":          "TLS1_2",
			"account_kind" :    "StorageV2",
			"storage_end_point_name" : "pepsaseus2ihubbatchtest",
			"subresource_names" : "blob",
			"enableblobcontainer" : false,
			"is_hns_enabled":true,
			"nfsv3_enabled":true,
			"vnet_subnet_id":"/subscriptions/f2872b28-84f4-4738-b870-1669037f0e95/resourceGroups/rg-ads-eus2-core-dev-nw-001/providers/Microsoft.Network/virtualNetworks/vnet-ads-eus2-core-dev-001/subnets/sn-ads-eus2-core-dev-ss-001",
			/*"storage_sid": "S-1-5-21-1375704250-3364174908-99390910-43775",
			"domain_name":"corpdev",
			"domain_sid":"S-1-5-21-1375704250-3364174908-99390910",
			"domain_guid":"95ad3035-ba5a-4399-8c1a-b4a876cda09c",
			"forest_name":"alldatadev.net",
			"netbios_domain_name":"CORPDEV",*/
			"enablestorageaccount" :"true", 
			"enable_https_traffic_only" :"false",
			"enablestoragepep" :"false",

		},
	}

	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	output := terraform.Output(t, terraformOptions, "StorageAccountName")
	assert.Equal(t, "saseus2eboihubbatch01t", output)
}


func TestAppserviceplan(t *testing.T) {
	//t.Parallel()
	terraformOptions := &terraform.Options{
		TerraformDir: "./Fixtures/appserviceplan",

		Vars: map[string]interface{}{

			"region":          "eastus2",
			"appServPlanName": "appsvcpl-ads-eus2-entbusops-dev-ihub-batch-001-test",
			"rgName":          "rg-ads-eus2-entbusops-dev-ihub-batch-001",
			"kind":            "elastic",
			"reserved":        true,
			"maximum_elastic_worker_count": 20,
			"appServPlanTier": "ElasticPremium",
			"appServPlanSKU":  "EP1",
		},
	}
	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	//Module Name from main.tf
	output := terraform.Output(t, terraformOptions, "ServicePlanName")
	assert.Equal(t, "appsvcpl-ads-eus2-entbusops-dev-ihub-batch-001-test", output)
}

func TestDataFactory(t *testing.T) {
	//t.Parallel()
	terraformOptions := &terraform.Options{
		TerraformDir: "./Fixtures/datafactory",

		Vars: map[string]interface{}{
			"region"							:"eastus2",
			"df_name"							: "adf-ads-eus2-entbusops-dev-ihub-batch-001-test",
			"rgName"							: "rg-ads-eus2-entbusops-dev-ihub-batch-001",
			"account_name"						: "cardservices",
			"branch_name"						: "main",
			"project_name"						: "Integration Hub Batch Processing",
			"repository_name"					: "ADF_IntegrationHubBatch",
			"root_folder"						: "/",
			"tenant_id"							: "7a24eae8-33b9-449a-83f5-361634c821ce",
			"public_network_enabled"			: false,
			//"enable_datafactory_pep"			: true,
			"df_end_point_name"					: "pep-adf-ads-eus2-entbusops-dev-ihub-batch-001-test",
			"pep_subnet_id"						: "/subscriptions/1fd4eaa2-e0f5-4e47-a395-12bad3a0cd73/resourceGroups/rg-ads-eus2-entbusops-dev-nw-001/providers/Microsoft.Network/virtualNetworks/vnet-ads-eus2-entbusops-int-dev-001/subnets/sn-ads-eus2-entbusops-dev-pep-001",
			"runtime_selfhostname"				: "adf-ads-eus2-entbusops-dev-ihub-batch-001-shir-test",
			"enable_datafactoryselfhosted"		: true,
			"linked_end_point_name" 			: "pep-adf-aml-ads-eus2-entbusops-dev-ihub-batch-001-test",
			"repository_name_aml" 				: "ADF_IntegrationAmlBatch",
			"identity_df" 						: "SystemAssigned",
			"project_name_aml" 					: "AML Data Hub Batch Processing",
			"enable_vsts_data_factory" 			: true,
			"linked_adf_name"					: "adf-aml-ads-eus2-entbusops-dev-ihub-batch-001-test",
			"enable_linked_shir" 				: false,
			"link_shir_name" 					: "adf-aml-ads-eus2-entbusops-dev-ihub-batch-001-shir-test",
			"enable_linked_datafactory"			: false,
			"enable_vsts_data_factory_aml" 		: false,
			"enable_adf_role_ass" 				: false,
			"enable_linkedadf_pep" 				: false,

		},
	}
	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	//Module Name from main.tf
	output := terraform.Output(t, terraformOptions, "data-factory")
	assert.Equal(t, "adf-ads-eus2-entbusops-dev-ihub-batch-001-test", output)
}


func TestPublicIP(t *testing.T) {
	//t.Parallel()
	terraformOptions := &terraform.Options{
		TerraformDir: "./Fixtures/publicIP",

		Vars: map[string]interface{}{
			"pipname":                 "pip-ads-eus2-entbusops-ihub-batch-dev-001-Test",
			"region":              "eastus2",
			"pip_sku":           "Standard",
			"resource_group_name": "rg-ads-eus2-entbusops-dev-ihub-batch-001",
			"idle_timeout_in_minutes":  "4",
			"allocationmethod":  "Static",
		},
	}
	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApply(t, terraformOptions)

	//Module Name from main.tf
	output := terraform.Output(t, terraformOptions, "public-ip")
	assert.Equal(t, "pip-ads-eus2-entbusops-ihub-batch-dev-001-Test", output)
}

func TestManagedDisk(t *testing.T) {
	// t.Parallel()
    terraformOptions := &terraform.Options{
        TerraformDir : "./Fixtures/managed_disk",
 
        Vars: map[string]interface{}{
            "vm_region"            : "eastus2",
            "vm_rgname"            : "rg-ads-eus2-entbusops-dev-ihub-batch-001",
            "storage_account_type" : "Premium_LRS",
            "managed_disks_name"   : "ACS29W280-data-01test", 
            "disk_size_gb"         : 256,
            "create_option"        : "Empty",
            "disk_zones"           : "1",
        },  
    }
   // At the end of the test, run `terraform destroy` to clean up any resources that were created
   defer terraform.Destroy(t, terraformOptions)

   // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
   terraform.InitAndApply(t, terraformOptions)

   output := terraform.Output(t, terraformOptions, "managed_disks_name")
   assert.Equal(t, "ACS29W280-data-01test",output)
} 