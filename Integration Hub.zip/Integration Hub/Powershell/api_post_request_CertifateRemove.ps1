﻿#  -----------------------------declare varriable -----------------------------
#debug
# $subscriptionId=(az account show --subscription "sub-ads-eus2-entops-inn-001" --query id -o tsv)
# $resourceGroupName="rg-ads-eus2-entops-inn-inhub-001" #"rg-ads-eus2-entbusops-dev-ihub-001"
# $location=( az group show --name $resourceGroupName --subscription $subscriptionId --query location -o tsv) #"eastus2"
# $ise_name="ise-ads-eus2-entops-inn-001" #"ise-ads-eus2-entbusops-dev-ihub-001"
#debug

[CmdletBinding()]
param ($resourceGroupName, $location,$ise_name,$apim_vault_name,$apim_cert_name,$ihub_vault_name,$ihub_root_cert,$ihub_retail_cert,$prootcert,$pintermediate,$send_patch)

az account show --query id --output tsv

$subscriptionId=(az account show --query id --output tsv)
# $resourceGroupName="$(terraformOutput.ise_resource_group)"
# $location="$(terraformOutput.ise_resource_location)"
# $ise_name="$(terraformOutput.ise_resourceName)"

Write-Host "****************************resourceGroupName: $resourceGroupName"  -fore green

Write-Host "****************************location*********: $location"  -fore green

Write-Host "****************************ise_name*********: $ise_name"  -fore green

Write-Host "****************************apim_vault_name*******: $apim_vault_name"  -fore green

Write-Host "****************************apim_cert_name***: $apim_cert_name"  -fore green

Write-Host "****************************ihub_root_cert********: $ihub_root_cert"  -fore green

Write-Host "****************************ihub_retail_cert****: $ihub_retail_cert"  -fore green

Write-Host "****************************send_path********: $send_patch"  -fore green

Write-Host "****************************ADS Cert********ihub_vault_name: $ihub_vault_name "  -fore green
Write-Host "****************************ADS Cert******** ihub_root_cert: $ihub_root_cert "  -fore green
Write-Host "****************************ADS Cert********ihub_retail_cert: $ihub_retail_cert "  -fore green

#ADS root certificate
#$rootcert=(Get-Content ("$(rootcert.secureFilePath)") -Raw )
$rootcert=(az keyvault secret show --vault-name $ihub_vault_name --name $ihub_root_cert --query "value" -o tsv)

#ADS intermediate certificate
#$intermediate=(Get-Content ("$(intermediate.secureFilePath)") -Raw)
$intermediate=(az keyvault secret show --vault-name $ihub_vault_name --name $ihub_retail_cert --query "value" -o tsv)

$rootcert=$rootcert.replace('-----BEGIN CERTIFICATE-----','').replace('-----END CERTIFICATE-----','').replace("`n","").Trim()
$intermediate=$intermediate.replace('-----BEGIN CERTIFICATE-----','').replace('-----END CERTIFICATE-----','').replace("`n","").Trim()

#get access token
$accessToken=(az account get-access-token --subscription $subscriptionId --query accessToken -o tsv)

# Create API URI for updating ISE certificates
$uri="https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Logic/integrationServiceEnvironments/$ise_name"+"?api-version=2019-05-01"

#download  APIM certificate from keyvault
az keyvault certificate download --vault-name $apim_vault_name -n $apim_cert_name -f apim_cert.pem

# read apim certificate
$apim_cert = Get-Content ("$pwd\apim_cert.pem") -Raw 
# remove extra character from certificate
$apim_cert =$apim_cert.replace('-----BEGIN CERTIFICATE-----','').replace('-----END CERTIFICATE-----','').replace("`n","").Trim()

if([string]::IsNullOrWhiteSpace($rootcert) -or [string]::IsNullOrWhiteSpace($intermediate) -or [string]::IsNullOrWhiteSpace($apim_cert)){
   throw "please check root, retail and apim certficates"
}

$body = @{
   "id"= "/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Logic/integrationServiceEnvironments/$ise_name"
   "name"= "$ise_name"
   "type"= "Microsoft.Logic/integrationServiceEnvironments"
   "location"= $location
   "properties"= @{
      "certificates"= @{ 
        
      }
   }
} | ConvertTo-Json -Depth 3

$header = @{
 "Accept"="application/json"
 "Authorization"="Bearer $accessToken"
 "Content-Type"="application/json"
} 
#  -----------------------------declare varriable -----------------------------
Write-Host "****************************print patch request body*******************************" -fore green
$body
Write-Host "****************************print patch request header******************************" -fore green
$header
Write-Host "****************************print patch request URI********************************" -fore green
$uri

if($send_patch -eq 1){
Write-Host "****************************send patch request****************************"  -fore green

Invoke-RestMethod -Uri $uri -Method 'Patch' -Body $body -Headers $header #| ConvertTo-HTML
}