package test

import (
  "github.com/gruntwork-io/terratest/modules/terraform"
  "testing"
  "github.com/stretchr/testify/assert"
)

func TestAppServicePlan(t *testing.T) {
  // t.Parallel()

    terraformOptions := &terraform.Options{

      
      TerraformDir : "./Fixtures/AppServicePlan",
    
     Vars: map[string]interface{}{
   
    "region"      :  "eastus2",
    "spTier"      : "Premium",
    "spSKU"       : "EP1",
    "kind"        : "FunctionApp",
    "AppResourceGroup" : "rg-ads-eus2-entbusops-dev-ihub-001",
    "AppServicePlanName" : "appsvcpl-ads-eus2-dev-ihub-001t",
    "maximum_elastic_worker_count" : "5",

  },
}
    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)

    output := terraform.Output(t, terraformOptions, "ServicePlanName")
	  assert.Equal(t, "appsvcpl-ads-eus2-dev-ihub-001t",output)

}

func TestAppInsight(t *testing.T) {
  // t.Parallel()

    terraformOptions := &terraform.Options{

      
      TerraformDir : "./Fixtures/AppInsight",
    
     Vars: map[string]interface{}{
   
    "region"      :  "eastus2",
    "rgName" : "rg-ads-eus2-entbusops-dev-ihub-001",
    "appinsightname" : "appin-ads-eus2-dev-ihub-001t",
    "applicationtype"      : "web",
  },
}

    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)

    output := terraform.Output(t, terraformOptions, "appinsights_name")
	  assert.Equal(t, "appin-ads-eus2-dev-ihub-001t",output)

}

func TestStorageAccount(t *testing.T) {
  // t.Parallel()

    terraformOptions := &terraform.Options{
      
      TerraformDir : "./Fixtures/StorageAccount",
    
     Vars: map[string]interface{}{
    "saName" : "stgadseus2entbusopsih01t",
    "rgName" : "rg-ads-eus2-entbusops-dev-ihub-001",
    "region" : "eastus2",
    "saTier" : "Standard",
    "saRepType" : "LRS",
    "NetworkRuleDefaultAction" : "Allow",
    "data_func_subnet_name"      : "sn-ads-eus2-entbusops-dev-ihub-fnc-001",
    "vnet_name" : "vnet-ads-eus2-entbusops-dev-ihub-001",
    "enable_storage_pep" : false,
    "StorageAccountContainerName" :"test",
    "StorageAccountContainerAccessType" : "private",
    "storage_end_point_name" : "testendpoint",
    "container_accesstype"    : "private", 
    "subresource_names"        : "blob",
    "storageacccontainername"  : "api-payload-test",
    "enableblobcontainer"      : true,
    "min_tls_version"          : "TLS1_2",
    "enablestorageaccount"     : true,
  },

  }

    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)

    output := terraform.Output(t, terraformOptions, "staccname1")
    assert.Equal(t, "stgadseus2entbusopsih01t",output)
} 
/*
func TestFunctionApp(t *testing.T) {
  // t.Parallel()
    terraformOptions := &terraform.Options{
      TerraformDir : "./Fixtures/FunctionApp",
      Vars: map[string]interface{}{
        //"saName"  : "stgadseus2entbusops03",
        "functionName"    : "funcapp-ads-eus2-entbusops-dev-ihub-001t",
        "region"          :  "eastus2",
        "rgName"          : "rg-ads-eus2-entbusops-dev-ihub-001",
        "linuxfxversion"     : "PYTHON|3.7",
        "IdentityType"     : "SystemAssigned",
        "ftpsstate"     : "Disabled",
        "OSVersion"  : "3",
        "IsHttpsOnly"     : true,
        "ostype"  : "linux",
        "functionWorkerRuntime"     : "python",
        "EnableAppServiceStorage"     : true,
        "funPrivateEndPointName"    : "pep-ads-eus2-entbusops-dev-ihub-001t", 
        },
    }
    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)
    output := terraform.Output(t, terraformOptions, "functionapp_name")
    assert.Equal(t, "funcapp-ads-eus2-entbusops-dev-ihub-001t",output)
  }*/
  
    /*func TestKeyvault(t *testing.T) {
      // t.Parallel()
        terraformOptions := &terraform.Options{
          TerraformDir : "./Fixtures/KeyVault",
          Vars: map[string]interface{}{
            "keyvaultName" :      "kvadseus2ihub01t", 
            "location" : "eastus2",
            "rgName"   : "rg-ads-eus2-entbusops-dev-ihub-001",
            "keyvault_sku_name" : "standard",
            "region" : "East US 2",
            "key_vault_end_point_name" : "pep-ads-eus2-ihub-kv-001t",
            "data_func_subnet_name" : "sn-ads-eus2-entbusops-dev-ihub-pep-001" , 
            "vnet_name" : "vnet-ads-eus2-entbusops-dev-ihub-001" , 
            
           },
        }
        // At the end of the test, run `terraform destroy` to clean up any resources that were created
        defer terraform.Destroy(t, terraformOptions)
    
        // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
        terraform.InitAndApply(t, terraformOptions)
        output := terraform.Output(t, terraformOptions, "keyvaultname")
        assert.Equal(t, "kvadseus2ihub01t",output)
      } */

func TestAppService(t *testing.T) {
  // t.Parallel()
    terraformOptions := &terraform.Options{
      TerraformDir : "./Fixtures/AppService",
       Vars: map[string]interface{}{
        //"saName"  : "stgadseus2entbusops03",
         "appServiceName"            : "appsvc-ads-eus2-entbusops-dev-ihub-001t",
         "region"                    : "eastus2",
         "rgName"                    : "rg-ads-eus2-entbusops-dev-ihub-001",
         "applinuxfxversion"         : "JAVA|11-java11",
         "ftpsstate"                 : "FtpsOnly",
         "http2_enabled"             : true,
         "javaversion"               : "11",
         "javacontainer"             : "JAVA",
         "javacontainerversion"      : "11",
         "enable_appsvc_pep"         : false,
         "appservice_end_point_name" : "pep-ads-eus2-entbusops-dev-ihub-001t",  
         "client_cert_enabled"       : true,
         "https_only"                      : true,
         "auth_settings_enabled"           : true,
         "detailed_error_messages_enabled" : true,
         "failed_request_tracing_enabled"  : true,
         "dotnet_framework_version"        : "v4.0",
         "php_version"                     : "7.4",
         "python_version"                  : "3.4",
         "identity_type"                   : "SystemAssigned",
         "health_check_path"               : "/",
         "kvname"                          : "kvadseus2entbusopsihub1",
         "kvrgname"                        : "rg-ads-eus2-entbusops-dev-ihub-001",

       },
    }
    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)
    output := terraform.Output(t, terraformOptions, "appservice_name")
    assert.Equal(t, "appsvc-ads-eus2-entbusops-dev-ihub-001t",output) 
     outputt := terraform.Output(t, terraformOptions, "appLinuxVersion")
     assert.Equal(t, "JAVA|11-java11",outputt)
}
/*
func TestLogAnalyticsWorkspace(t *testing.T) {
  // t.Parallel()

    terraformOptions := &terraform.Options{

      
      TerraformDir : "./Fixtures/LogAnalyticsWorkspace",
    
     Vars: map[string]interface{}{
   
    "name"              : "law-ads-eus2-entbusops-dev-001-t",
    "location"          : "eastus2",
    "sku"               : "PerGB2018",
    "retention_in_days" : "30",
  },
}

    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)

    output := terraform.Output(t, terraformOptions, "name")
	  assert.Equal(t, "law-ads-eus2-entbusops-dev-001-t",output)

}

func TestPrivateEndPoint(t *testing.T) {
  // t.Parallel()
    terraformOptions := &terraform.Options{
      TerraformDir : "./Fixtures/Private-End-Point",
       Vars: map[string]interface{}{
        "privateendpointname"                  : "privateendpointtest",
        "region"                               : "East US 2",
        "rgName"                               : "rg-ads-eus2-entbusops-dev-ihub-001",
        "privateconnectionresourceid"          : "test",
        "IsManualConnectionForPrivateEndPoint" : false,
        "PrivateEndPointSubResourceName"       : "sites",
         
       },
    }
    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)
    output := terraform.Output(t, terraformOptions, "private_endpoint")
    assert.Equal(t, "privateendpointtest",output)
}
*/

 
 